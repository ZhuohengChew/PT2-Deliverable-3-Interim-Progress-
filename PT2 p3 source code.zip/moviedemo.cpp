#include<iostream>
#include "Movie.hpp"
#include<vector>
#include<fstream>
#include<iomanip>
using namespace std;

int main(){
    Movie m1("Angry Bird", 2020, 12, 0, "PG13", "animation");

    m1.display();
    cout<<"------------------------------"<<endl;

    m1.setName("Angry Cat");
    m1.setYear(2005);
    m1.setRating(8);
    m1.setClassification("G");
    m1.setGenre("horror");
    m1.setRatingNum(1);
    cout<<m1.getRating()<<endl;
    m1.renewRating(10);
    cout<<m1.getRating()<<endl;

    cout<<"------------------------------"<<endl;
    cout<<m1.getName()<<endl;
    cout<<m1.getGenre()<<endl;
    cout<<m1.getRating()<<endl;
    cout<<m1.getRatingNum()<<endl;
    cout<<m1.getYear()<<endl;

    cout<<"------------------------------"<<endl;
    m1.display();

    cout<<"------------------------------"<<endl;
    m1.displayClassification(10);

    system("pause");
    return 0;
}