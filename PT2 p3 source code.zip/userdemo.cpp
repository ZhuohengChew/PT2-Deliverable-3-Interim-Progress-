#include<iostream>
#include"fMovie.hpp"
#include "Movie.hpp"
#include "GMovie.hpp"
#include "NC17Movie.hpp"
#include "PG13Movie.hpp"
#include "PGMovie.hpp"
#include "RMovie.hpp"
#include "user.hpp"
#include<vector>
#include<fstream>
#include<iomanip>
using namespace std;

int main() {
    //Read file
    vector<User> users;
    vector<Movie> movies;
    vector<GMovie> gmovies;
    vector<NC17Movie> nc17movies;
    vector<PG13Movie> pg13movies;
    vector<PGMovie> pgmovies;
    vector<RMovie> rmovies;
    fMovie fmovies;
    ifstream fin("users.txt");
    int userCount = 0;

try {
        if (!fin.is_open()) {
            throw runtime_error("Failed to open the file.");
        }

    while (!fin.eof()) {
        string name;
        string pass;
        int age;
        getline(fin, name);
        if (name.empty()) break; // Skip empty lines
        fin >> pass >> age;
        fin.ignore(); // Ignore the newline character after age
        User newUser;
        newUser.setUsername(name);
        newUser.setPassword(pass);
        newUser.setAge(age);
        users.push_back(newUser);

        userCount++;
    }
    fin.close();
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
        if (fin.is_open()) {
            fin.close();
        }
        system("pause");
        return 1; // Return with an error code
    }
    
    int movieCount = 0;
    ifstream moviefin("movie.txt");
try {
    if (!moviefin.is_open()) {
        throw runtime_error("Failed to open the file.");
    }
    while (!moviefin.eof()) {
        string name;
        int year;
        double rating;
        string classification;
        int ratingNum;
        string genre;
        getline(moviefin, name);
        if (name.empty()) break; // Skip empty lines
        moviefin >> year >> ratingNum >> rating >> classification >> genre;
        moviefin.ignore(); // Ignore the newline character after genre
        Movie newMovie;
        newMovie.setName(name);
        newMovie.setYear(year);
        newMovie.setRating(rating);
        newMovie.setClassification(classification);
        newMovie.setRatingNum(ratingNum);
        newMovie.setGenre(genre);
        movies.push_back(newMovie);
        movieCount++;

        if (classification == "G") {
            GMovie newMovie(name, year, ratingNum, rating, genre);
            gmovies.push_back(newMovie);
        } else if (classification == "PG-13") {
            PG13Movie newMovie(name, year, ratingNum, rating, genre);
            pg13movies.push_back(newMovie);
        } else if (classification == "R") {
            RMovie newMovie(name, year, ratingNum, rating, genre);
            rmovies.push_back(newMovie);
        } else if (classification == "PG") {
            PGMovie newMovie(name, year, ratingNum, rating, genre);
            pgmovies.push_back(newMovie);
        } else if (classification == "NC-17") {
            NC17Movie newMovie(name, year, ratingNum, rating, genre);
            nc17movies.push_back(newMovie);
        }
    }
    } catch (const exception& e) {
    cerr << "Exception: " << e.what() << endl;
    if (moviefin.is_open()) {
        moviefin.close();
    }
    system("pause");
    return 1; // Return with an error code
    }
    moviefin.close();
    //End of read file

    //Start the main program 
    int id =  readID(users,userCount);
    if (id != -1) {
        users[id].readWatchlist();
        users[id].PointfMovies(&fmovies);
        users[id].readfavouritelist();
        cout << "Successfully login!" << endl;
    } else {
        cout << "Invalid username or password." << endl;
        system("pause");
        return 1; // Return with an error code
    }
    
    User newUser;
    newUser.createAccount(users,userCount);
    users.push_back(newUser);  // Add the new user to the vector
    int userIndex = userCount++;
    if (userIndex != -1) {
        users[userIndex].readWatchlist();
        users[userIndex].PointfMovies(&fmovies);
    } else {
        cout << "Invalid username or password." << endl;
        system("pause");
        return 1; // Return with an error code
    }
    

    char choice;
    cout<<"Do you want to add movie into your watchlist?(Enter 'Y' or 'y'):";
    cin>>choice;
    if(choice=='Y'||choice=='y'){
    int movieNum;
    do {
        cout << "Enter number of movie to add to watchlist (Enter -1 to exit): ";
        cin >> movieNum;
        if(movieNum >= 0 && movieNum <= movieCount) {
            users[userIndex].addToWatchlist(movies[movieNum-1]);
        } else if(movieNum != -1) {
            cout << "Invalid movie number. Please try again." << endl;
        }
    } while(movieNum != -1);
    }
    cout << "Exit!" << endl<<endl;
    
    cout<<"If you want to delete movie from watchlist ENTER Y: ";
    cin>>choice;
    int movieNum;
    if(choice=='Y'||choice=='y'){
        do{
        cout<<"Enter the number of movie you want to delete: ";
        cin>>movieNum;
        }while(movieNum>users[userIndex].getWlistCnt());
        users[userIndex].removeFromWatchlist(movieNum);
    }
    else{
        cout<<"Exit!"<<endl<<endl;
    }
    
    cout << "<-----The current favourite movie list----->" << endl;
    users[userIndex].displayfmovielist();

    cout<<"Do you want to add movie into your favourite movies list?(Enter 'Y' or 'y'):";
    cin>>choice;
    cin.ignore();
    if(choice=='Y'||choice=='y'){
    int movieNum;
    do {
        cout << "Enter number of movie to add to favourite movies list (Enter -1 to exit): ";
        cin >> movieNum;
        if(movieNum >= 0 && movieNum <= movieCount) {
            bool repeat=(users[userIndex].setfavouriteMovie(movies[movieNum-1]));
            if(!repeat)users[userIndex].printfavouriteMovieintxt();
        } else if(movieNum != -1) {
            cout << "Invalid movie number. Please try again." << endl;
        }
    } while(movieNum != -1);
    
    }
    cout << "Exit!" << endl<<endl;

    cout << "<-----The latest favourite movie list----->" << endl;
    users[userIndex].displayfmovielist();

    system("pause");
    return 0;
}