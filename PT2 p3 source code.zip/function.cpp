#include<iostream>
#include"fMovie.hpp"
#include "Movie.hpp"
#include "GMovie.hpp"
#include "NC17Movie.hpp"
#include "PG13Movie.hpp"
#include "PGMovie.hpp"
#include "RMovie.hpp"
#include "user.hpp"
#include<vector>
#include<fstream>
#include<iomanip>
using namespace std;

int userinput(vector<User>& users, int& userCount) {
    int x = 0;
    int id;
    cout << "Login or create account?\n";
    cout << "Press 1 to login\nPress 2 to create account\n";
    while (x != 1 && x != 2) {
        cout << "Enter: ";
        cin >> x;
        switch (x){
                case 1:id = readID(users,userCount);
                break;
        case 2: {
                    User newUser;
                    newUser.createAccount(users,userCount);
                    users.push_back(newUser);  // Add the new user to the vector
                    id = userCount++;
                    break;  // Increment userCount after adding the new user
                }
        default:{
            cout << "Invalid input..\n";
        }
    }
    }
    return id;
};

int searchMovie(vector<Movie>& movies,int movieCount){
    string str;
    //cin.ignore();
    cout<<"Enter movie name: ";
    getline(cin,str);
    for(int i=0;i<movieCount;i++){
        if(str==movies[i].getName()){
            return i;
        }
    }
    return -1;
}

void searchclassification(vector<User> users,int userIndex,vector<GMovie> gmovies,vector<NC17Movie> nc17movies,vector<PG13Movie> pg13movies,vector<PGMovie> pgmovies,vector<RMovie> rmovies){
    int choice=0;
    int filmNum;
    bool legal;

    do{
    cout<<"Enter 1 for General rated film\n";
    cout<<"Enter 2 for PG rated film\n";
    cout<<"Enter 3 for PG-13 rated film\n";
    cout<<"Enter 4 for R rated film\n";
    cout<<"Enter 5 for NC-17 rated film\nEnter: ";
    cin>>choice;
    switch(choice){
        case 1:{
            legal=gmovies[0].displayClassification(users[userIndex].getAge());
        if(legal){
        for(int i=0;i<gmovies[0].getCnt();i++){
            cout<<i+1<<".";
            gmovies[i].display();
        }
        }
        else
            return;
        break;}

        case 2:{
        legal=pgmovies[0].displayClassification(users[userIndex].getAge());
        if(legal){
        for(int i=0;i<pgmovies[0].getCnt();i++){
            cout<<i+1<<".";
            pgmovies[i].display();
        }
        }
        else
            return;
        break;}

        case 3:{
            legal=pg13movies[0].displayClassification(users[userIndex].getAge());
        if(legal){
        for(int i=0;i<pg13movies[0].getCnt();i++){
            cout<<i+1<<".";
            pg13movies[i].display();
        }
        }
        else
            return;
        break;}

        case 4:{
            legal=nc17movies[0].displayClassification(users[userIndex].getAge());
        if(legal){
        for(int i=0;i<nc17movies[0].getCnt();i++){
            cout<<i+1<<".";
            nc17movies[i].display();
        }
        }
        else
            return;
        break;}
        case 5:{
            legal=rmovies[0].displayClassification(users[userIndex].getAge());
        if(legal){
        for(int i=0;i<rmovies[0].getCnt();i++){
            cout<<i+1<<".";
            rmovies[i].display();
        }
        }
        else
            return;
        break;}
        default:
        cout<<"Invalid input,Enter again..\n";
    }}while(choice<1||choice>5);

    do{
    switch(choice){

        case 1:{
        cout<<"Enter the number of film to add to watchlist(Enter more than total movie will exit):";
        cin>>filmNum;
        if(filmNum>gmovies[0].getCnt()||filmNum<1){
        cout<<"Exit..."<<endl;
        return;}
        else
        users[userIndex].addToWatchlist(gmovies[filmNum-1]);
        break;}

        case 2:{
        cout<<"Enter the number of film to add to watchlist(Enter more than total movie will exit):";
        cin>>filmNum;
        if(filmNum>pgmovies[0].getCnt()||filmNum<1){
        cout<<"Exit..."<<endl;
        return;}
        else
        users[userIndex].addToWatchlist(pgmovies[filmNum-1]);
        break;}

        case 3:{
        cout<<"Enter the number of film to add to watchlist(Enter more than total movie will exit):";
        cin>>filmNum;
        if(filmNum>pg13movies[0].getCnt()||filmNum<1){
        cout<<"Exit..."<<endl;
        return;}
        else
        users[userIndex].addToWatchlist(pg13movies[filmNum-1]);
        break;}

        case 4:{
        cout<<"Enter the number of film to add to watchlist(Enter more than total movie will exit):";
        cin>>filmNum;
        if(filmNum>nc17movies[0].getCnt()||filmNum<1){
        cout<<"Exit..."<<endl;
        return;}
        else
        users[userIndex].addToWatchlist(nc17movies[filmNum-1]);
        break;}

        case 5:{
        cout<<"Enter the number of film to add to watchlist(Enter more than total movie will exit):";
        cin>>filmNum;
        if(filmNum>rmovies[0].getCnt()||filmNum<1){
        cout<<"Exit..."<<endl;
        return;}
        else
        users[userIndex].addToWatchlist(rmovies[filmNum-1]);
        break;}

        default:
        cout<<"Invalid input,Enter again..\n";
    }
    }while(true);

    
}

void searchgenre(vector<Movie>& movies, vector<User>& users, int userIndex, int movieCount) {
    cout << "Search by Genre\n";
    cout << "Enter 1 for Sci-fi\n";
    cout << "Enter 2 for Horror\n";
    cout << "Enter 3 for Animation\n";
    cout << "Enter 4 for Fantasy\n";
    cout << "Enter 5 for Adventure\n";
    cout << "Enter 6 for Action\n";
    cout << "Enter 7 for Comedy\n";
    cout << "Enter 8 for Crime\n";
    cout << "Enter 9 for Romance\n";
    cout << "Enter 10 for Drama\n";
    cout << "Enter 11 for War\n";
    cout << "Enter 12 for Thriller\n";
    cout << "Enter 13 for Musical\n";
    cout << "Enter 14 for Western\n";
    cout << "Enter 15 for Biography\n";
    cout << "Enter : ";
    int choice;
    cin >> choice;
    string genres[] = {
        "sci-fi", "horror", "animation", "fantasy", "adventure",
        "action", "comedy", "crime", "romance", "drama",
        "war", "thriller", "musical", "western", "biography"
    };
    string genre;
    vector<Movie> genreMovies;
    int genreCnt = 0;

    if (choice >= 1 && choice <= 15) {
        genre = genres[choice - 1];
        }
    else{ 
            cout << "Invalid input...Exit" << endl;
            return;
    }

    for (int i = 0; i < movieCount; i++) {
    if (genre == movies[i].getGenre()) {
        genreMovies.push_back(movies[i]);
        //users[userIndex].setfavouriteMovie(movies[i]);
        cout << genreCnt + 1 << ".";
        genreMovies[genreCnt++].display();
    }
}

//users[userIndex].printfovouriteMovieintxt();

    int movieNum;
    do {
        cout << "Enter number of movie to add to watchlist (Enter -1 to exit): ";
        cin >> movieNum;
        if(movieNum >= 1 && movieNum <= genreCnt) {
            users[userIndex].addToWatchlist(genreMovies[movieNum-1]);
        } else if(movieNum != -1) {
            cout << "Invalid movie number. Please try again." << endl;
        }
    } while(movieNum != -1);

    cout << "Exit!" << endl;
}

void rateMovie(vector<Movie>& movies, int movieCount){
    for(int i=0;i<movieCount;i++){
        cout<<i+1<<".";
        movies[i].display();
    }
    int choice;
    do{
    cout<<"Enter number of film to rate: ";
    cin>>choice;
    }while(choice>movieCount);
    double rate;
    do{
    cout<<"Rate 0 to 10: ";
    cin>>rate;
    }while(rate>10||rate<0);
    movies[choice-1].renewRating(rate);
    cout<<fixed<<setprecision(2);
    cout<<"Newest rating : "<<movies[choice-1].getRating()<<endl;

    ofstream update("movie.txt");
    for(int i=0;i<movieCount;i++){
        update<<fixed<<setprecision(2);
        update<<movies[i].getName()<<endl;
        update<<movies[i].getYear()<<" "<<movies[i].getRatingNum()<<" "<<movies[i].getRating()<<" "<<movies[i].getClassification()<<" "<<movies[i].getGenre()<<endl;
    }

    update.close();
}

void viewWatchlist(vector<User>& users, int userIndex){
    for(int i=0;i<users[userIndex].getWlistCnt();i++){
        cout<<i+1<<".";
        (users[userIndex]).watchlist[i].display();
    }

    cout<<"If you want to delete movie from watchlist ENTER Y: ";
    char choice;
    cin>>choice;
    int movieNum;
    if(choice=='Y'||choice=='y'){
        do{
        cout<<"Enter the number of movie you want to delete: ";
        cin>>movieNum;
        }while(movieNum>users[userIndex].getWlistCnt());
        users[userIndex].removeFromWatchlist(movieNum);
    }
    else{
        cout<<"Exit!"<<endl;
    }
}

void viewmovielist(vector<Movie>& movies,int movieCount,vector<User>& users, int userIndex){
    for(int i=0;i<movieCount;i++){
        cout<<i+1<<".";
        movies[i].display();
    }
    char choice;
    cout<<"Do you want to add movie into your watchlist?(Enter 'Y' or 'y'):";
    cin>>choice;
    if(choice=='Y'||choice=='y'){
    int movieNum;
    do {
        cout << "Enter number of movie to add to watchlist (Enter -1 to exit): ";
        cin >> movieNum;
        if(movieNum >= 0 && movieNum <= movieCount) {
            users[userIndex].addToWatchlist(movies[movieNum-1]);
        } else if(movieNum != -1) {
            cout << "Invalid movie number. Please try again." << endl;
        }
    } while(movieNum != -1);
    }
    cout << "Exit!" << endl<<endl;
}

void addtofavouritemovie(vector<Movie>& movies,int movieCount,vector<User>& users, int userIndex){
    for(int i=0;i<movieCount;i++){
        cout<<i+1<<".";
        movies[i].display();
    }
    char choice;
    cout<<"Do you want to add movie into your favourite movies list?(Enter 'Y' or 'y'):";
    cin>>choice;
    cin.ignore();
    if(choice=='Y'||choice=='y'){
    int movieNum;
    do {
        cout << "Enter number of movie to add to favourite movies list (Enter -1 to exit): ";
        cin >> movieNum;
        if(movieNum >= 0 && movieNum <= movieCount) {
            bool repeat=(users[userIndex].setfavouriteMovie(movies[movieNum-1]));
            if(!repeat)users[userIndex].printfavouriteMovieintxt();
        } else if(movieNum != -1) {
            cout << "Invalid movie number. Please try again." << endl;
        }
    } while(movieNum != -1);
    
    }
    cout << "Exit!" << endl<<endl;
}

void viewallfmovielist(vector<User>& users, int userIndex){
    users[userIndex].displayfmovielist();
    char choicedelete;
    cout<<"If you want to delete movie from favourite movies list Press y or Y:";
    cin>>choicedelete;
    if(choicedelete=='Y'||choicedelete=='y'){
        int num;
        do{
            cout<<"Enter the value within number of movie in favourite movie list:";
            cin>>num;
            if((num>=1&&num<=users[userIndex].getfMovieCnt())){
            users[userIndex].removeFromfMovielist(num);
            break;}
            else
            cout<<"Invalid value,please enter again.\n";
        }while(true);

    }
            
        cout<<"Exit.."<<endl;
}

void userchoice(vector<User> &users,vector<Movie>& movies,int movieCount,int userIndex,vector<GMovie> gmovies,vector<NC17Movie> nc17movies,vector<PG13Movie> pg13movies,vector<PGMovie> pgmovies,vector<RMovie> rmovies){
    int choice;
    int searchedmovie;
    do{
    cout<<"Welcome to CineMatch\n";
    cout<<"Enter 1 to search movie by movie NAME\n";
    cout<<"Enter 2 to search movie by movie classification\n";
    cout<<"Enter 3 to search movie by genre\n";
    cout<<"Enter 4 to rate movie\n";
    cout<<"Enter 5 to view watchlist\n";
    cout<<"Enter 6 to view all movielist\n";
    cout<<"Enter 7 to add movies into favourite movie list\n";
    cout<<"Enter 8 to view all favourite movie list\n";
    cout<<"Other input will exit\n";
    cout<<"Enter :";
    cin>>choice;
    cin.ignore();
    switch (choice){
        case 1:{
            do{
            searchedmovie=searchMovie(movies,movieCount);
            if(searchedmovie!=-1)
            movies[searchedmovie].display();
            else
            {cout<<"The entered movie not exist..\n";
            }
            }while(searchedmovie==-1);
            cout<<"Do you want to add to watchlist?(If yes enter Y or y):";
            char choice;
            cin>>choice;
            if(choice=='Y'||choice=='y'){
                users[userIndex].addToWatchlist(movies[searchedmovie]);
            }
            break;
        }
        case 2:{searchclassification(users,userIndex,gmovies,nc17movies,pg13movies,pgmovies,rmovies);
                break;
        }
        case 3:{searchgenre(movies,users,userIndex,movieCount);break;}
        case 4:{rateMovie(movies,movieCount);break;}
        case 5:{viewWatchlist(users,userIndex);break;}
        case 6:{viewmovielist(movies,movieCount,users,userIndex);break;}
        case 7:{addtofavouritemovie(movies,movieCount,users,userIndex);break;}
        case 8:{viewallfmovielist(users,userIndex);break;}
    }
    }while(choice>=1&&choice<=8);
}

